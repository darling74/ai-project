"""Flask application: AI violence detection in videos (pretrained X3D-M)."""
from __future__ import annotations

import hmac
import logging
import re
import threading
import uuid
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Dict, Optional

from flask import Flask, jsonify, render_template, request
from werkzeug.exceptions import HTTPException, RequestEntityTooLarge

from config import Settings, ModelSpec, load_model_spec
from jobs import JobManager, error_payload, purge_stale_files, safe_remove
from video_processor import VideoAnalyzer, VideoDecodeError, probe_video
from violence_model import ModelUnavailableError, get_model

log = logging.getLogger("violence_app")


def configure_logging(settings: Settings) -> None:
    root = logging.getLogger()
    if any(getattr(h, "_violence_app", False) for h in root.handlers):
        return
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    handlers = [logging.StreamHandler()]  # console / platform log viewer
    if settings.log_to_file:
        settings.log_dir.mkdir(parents=True, exist_ok=True)
        handlers.append(RotatingFileHandler(settings.log_dir / "app.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8"))
    for h in handlers:
        h.setFormatter(fmt)
        h._violence_app = True  # type: ignore[attr-defined]
        root.addHandler(h)
    root.setLevel(getattr(logging, settings.log_level, logging.INFO))


def api_error(code: str, message: str, status: int):
    return jsonify({"ok": False, "error": {"code": code, "message": message}}), status


def create_app(settings: Optional[Settings] = None, model: Any = None, spec: Optional[ModelSpec] = None) -> Flask:
    """Application factory.

    ``model`` may be injected (automated tests only); in normal use the cached
    pretrained :class:`ViolenceModel` is created from ``models/model_config.json``.
    """
    settings = settings or Settings.from_env()
    settings.ensure_dirs()
    configure_logging(settings)
    spec = spec or load_model_spec(settings.model_config_path)
    model = model if model is not None else get_model(spec, settings)

    app = Flask(__name__)
    app.config.update(SECRET_KEY=settings.secret_key, MAX_CONTENT_LENGTH=settings.max_upload_bytes + 1024 * 1024)
    analyzer = VideoAnalyzer(model, spec, settings.min_video_frames, settings.max_video_seconds,
                             settings.inference_batch_size)
    jobs = JobManager(analyzer, settings.job_ttl_seconds, settings.max_queue)
    app.extensions["violence"] = {"settings": settings, "spec": spec, "model": model, "jobs": jobs, "analyzer": analyzer}

    removed = purge_stale_files(settings.upload_dir, settings.stale_upload_seconds)
    if removed:
        log.info("Removed %d stale upload(s)", removed)
    if settings.model_preload and model.status().get("state") == "not_loaded":
        def _preload() -> None:
            try:
                model.load()
            except ModelUnavailableError as exc:
                log.error("Model preload failed: %s", exc)
        threading.Thread(target=_preload, name="model-preload", daemon=True).start()

    # ------------------------------------------------- optional password + headers
    auth_on = bool(settings.basic_auth_user and settings.basic_auth_password)

    @app.before_request
    def require_password():
        """Optional HTTP Basic auth (set BASIC_AUTH_USER and BASIC_AUTH_PASSWORD) to keep a public URL private."""
        if not auth_on:
            return None
        a = request.authorization
        ok = (a is not None and a.type == "basic"
              and hmac.compare_digest((a.username or "").encode(), settings.basic_auth_user.encode())
              and hmac.compare_digest((a.password or "").encode(), settings.basic_auth_password.encode()))
        if ok:
            return None
        resp = jsonify({"ok": False, "error": {"code": "unauthorized", "message": "Password required."}})
        resp.status_code = 401
        resp.headers["WWW-Authenticate"] = 'Basic realm="Violence detection"'
        return resp

    CSP = ("default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
           "font-src https://fonts.gstatic.com; img-src 'self' data: blob:; media-src 'self' blob:; "
           "connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'")

    @app.after_request
    def security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        resp.headers.setdefault("Content-Security-Policy", CSP)
        if request.path.startswith(("/api/", "/predict")):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    # ------------------------------------------------------------------ helpers
    JOB_ID_RE = re.compile(r"^[0-9a-f]{32}$")

    def allowed(filename: str) -> bool:
        return "." in filename and filename.rsplit(".", 1)[1].lower() in settings.allowed_extensions

    def accept_upload():
        """Validate and store the upload. Returns (path, original_name) or an error response."""
        status = model.status()
        if not status["available"] and status["state"] != "ready":
            return None, api_error(status["state"], status["message"], 503)
        file = request.files.get("video")
        if file is None or not file.filename:
            return None, api_error("no_file", "No video file was sent (form field 'video').", 400)
        if not allowed(file.filename):
            return None, api_error("bad_extension", "Unsupported file type. Allowed: "
                                   + ", ".join(e.upper() for e in settings.allowed_extensions) + ".", 400)
        ext = file.filename.rsplit(".", 1)[1].lower()
        path = settings.upload_dir / f"{uuid.uuid4().hex}.{ext}"
        file.save(path)
        try:
            if path.stat().st_size == 0:
                raise VideoDecodeError("The uploaded file is empty.")
            if path.stat().st_size > settings.max_upload_bytes:
                raise RequestEntityTooLarge()
            probe_video(path, settings.min_video_frames, settings.max_video_seconds)  # decoding validation
        except RequestEntityTooLarge:
            safe_remove(path)
            return None, api_error("too_large", f"File exceeds the {settings.max_upload_mb} MB limit.", 413)
        except VideoDecodeError as exc:
            safe_remove(path)
            return None, api_error("invalid_video", str(exc), 422)
        except Exception:
            safe_remove(path)
            log.exception("Upload validation failed")
            return None, api_error("internal_error", "Could not validate the uploaded video.", 500)
        return (path, file.filename), None

    # ------------------------------------------------------------------- routes
    @app.get("/")
    def home():
        return render_template("index.html", spec=spec, settings=settings)

    @app.get("/api/health")
    def health():
        return jsonify({
            "ok": True,
            "model": model.status(),
            "settings": {
                "max_upload_mb": settings.max_upload_mb,
                "allowed_extensions": list(settings.allowed_extensions),
                "threshold": spec.threshold,
                "aggregation": spec.aggregation,
                "segment_seconds": spec.segment_seconds,
            },
        })

    @app.post("/api/analyze")
    def analyze_async():
        if jobs.is_full():
            return api_error("busy", "The server is busy analysing other videos. Please try again in a minute.", 429)
        accepted, err = accept_upload()
        if err:
            return err
        path, name = accepted
        wanted = request.form.get("job_id", "")
        wanted = wanted if JOB_ID_RE.match(wanted) else None  # client-chosen id lets the page poll progress
        if settings.inline_processing:
            # Analyse inside this request (the job still deletes the file). Progress is polled via /api/jobs/<id>.
            job = jobs.run_inline(path, name, wanted)
            if job["state"] == "error":
                return api_error(job["error"]["code"], job["error"]["message"], job["error"]["http"])
            return jsonify({"ok": True, "job_id": job["id"], "state": "done", "result": job["result"]}), 200
        job_id = jobs.submit(path, name, wanted)  # the job deletes the file when finished
        return jsonify({"ok": True, "job_id": job_id}), 202

    @app.get("/api/jobs/<job_id>")
    def job_status(job_id: str):
        job = jobs.get(job_id)
        if job is None:
            return api_error("not_found", "Unknown or expired job.", 404)
        body: Dict[str, Any] = {"ok": True, "job_id": job_id, "state": job["state"], "progress": job["progress"]}
        if job["state"] == "done":
            body["result"] = job["result"]
        if job["state"] == "error":
            body["error"] = {k: job["error"][k] for k in ("code", "message")}
        return jsonify(body)

    @app.post("/predict")
    def predict_sync():
        """Synchronous endpoint (compatible with the original project's /predict)."""
        if jobs.is_full():
            return api_error("busy", "The server is busy analysing other videos. Please try again in a minute.", 429)
        accepted, err = accept_upload()
        if err:
            return err
        path, name = accepted
        job = jobs.run_inline(path, name)  # shares the queue/lock with the web page; deletes the file itself
        if job["state"] == "error":
            e = job["error"]
            return api_error(e["code"], e["message"], e["http"])
        return jsonify({"ok": True, **job["result"]})

    # ----------------------------------------------------------- error handling
    @app.errorhandler(RequestEntityTooLarge)
    def too_large(_exc):
        return api_error("too_large", f"File exceeds the {settings.max_upload_mb} MB limit.", 413)

    @app.errorhandler(HTTPException)
    def http_error(exc: HTTPException):
        return api_error((exc.name or "error").lower().replace(" ", "_"), exc.description or exc.name, exc.code or 500)

    @app.errorhandler(Exception)
    def unhandled(exc: Exception):
        log.exception("Unhandled error")
        return api_error("internal_error", "An unexpected server error occurred.", 500)

    return app


def main() -> None:
    settings = Settings.from_env()
    app = create_app(settings)
    log.info("Starting on http://%s:%d (debug=%s)", settings.host, settings.port, settings.debug)
    if settings.debug:
        log.warning("DEBUG is on - never use this in production.")
        app.run(host=settings.host, port=settings.port, debug=True, use_reloader=False)
        return
    try:
        from waitress import serve
        # threads>=4 so progress polls are answered while an analysis runs; long channel_timeout for slow uploads/analysis
        serve(app, host=settings.host, port=settings.port, threads=8, channel_timeout=900,
              max_request_body_size=settings.max_upload_bytes + 2 * 1024 * 1024)
    except ImportError:
        log.warning("waitress is not installed; using Flask's development server.")
        app.run(host=settings.host, port=settings.port, debug=False)


if __name__ == "__main__":
    main()
