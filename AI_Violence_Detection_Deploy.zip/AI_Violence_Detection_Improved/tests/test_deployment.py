import base64
import os
import unittest
from pathlib import Path
from unittest import mock

from app import create_app
from config import Settings
from tests.helpers import FakeMotionModel, default_spec, make_settings, tmpdir, write_video
from tests.test_app import wait_empty


class DeploymentTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tmpdir()
        self.tmp = Path(self._tmp.name)
        self.video = self.tmp / "clip.avi"
        write_video(self.video, seconds=3, size=(64, 48), kind="motion")

    def tearDown(self):
        self._tmp.cleanup()

    def client(self, **overrides):
        settings = make_settings(self.tmp, **overrides)
        app = create_app(settings, model=FakeMotionModel(), spec=default_spec())
        return app.test_client(), settings

    def post(self, c, url="/api/analyze", **extra):
        data = {"video": (open(self.video, "rb"), "clip.avi"), **extra}
        return c.post(url, data=data, content_type="multipart/form-data")

    # --- inline mode (analysis inside the upload request, e.g. Cloud Run)
    def test_inline_mode_returns_result_in_one_request_and_job_is_pollable(self):
        c, s = self.client(inline_processing=True)
        job_id = "a" * 32
        r = self.post(c, job_id=job_id)
        body = r.get_json()
        self.assertEqual(r.status_code, 200)
        self.assertEqual(body["state"], "done")
        self.assertEqual(body["job_id"], job_id)  # the client-chosen id is honoured
        self.assertEqual(body["result"]["label"], "violence")
        polled = c.get(f"/api/jobs/{job_id}").get_json()
        self.assertEqual(polled["state"], "done")
        self.assertTrue(wait_empty(s.upload_dir))

    def test_invalid_client_job_id_is_ignored(self):
        c, _ = self.client(inline_processing=True)
        body = self.post(c, job_id="../../etc/passwd").get_json()
        self.assertRegex(body["job_id"], r"^[0-9a-f]{32}$")

    def test_inline_corrupted_video_error(self):
        c, s = self.client(inline_processing=True)
        bad = self.tmp / "bad.mp4"
        bad.write_bytes(bytes(range(256)) * 40)
        r = c.post("/api/analyze", data={"video": (open(bad, "rb"), "bad.mp4")}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 422)
        self.assertTrue(wait_empty(s.upload_dir))

    # --- public-site protections
    def test_busy_queue_returns_429_and_stores_nothing(self):
        c, s = self.client(max_queue=0)
        for url in ("/api/analyze", "/predict"):
            r = self.post(c, url=url)
            self.assertEqual(r.status_code, 429, url)
            self.assertEqual(r.get_json()["error"]["code"], "busy")
        self.assertTrue(wait_empty(s.upload_dir))

    def test_predict_endpoint_still_works(self):
        c, s = self.client()
        r = self.post(c, url="/predict")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["prediction"], "Violence")
        self.assertTrue(wait_empty(s.upload_dir))

    def test_security_headers(self):
        c, _ = self.client()
        r = c.get("/")
        self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")
        self.assertIn("frame-ancestors 'none'", r.headers["Content-Security-Policy"])
        self.assertEqual(c.get("/api/health").headers["Cache-Control"], "no-store")

    def test_optional_password(self):
        c, _ = self.client(basic_auth_user="demo", basic_auth_password="s3cret")
        self.assertEqual(c.get("/").status_code, 401)
        self.assertEqual(c.get("/api/health").status_code, 401)
        good = {"Authorization": "Basic " + base64.b64encode(b"demo:s3cret").decode()}
        bad = {"Authorization": "Basic " + base64.b64encode(b"demo:wrong").decode()}
        self.assertEqual(c.get("/", headers=good).status_code, 200)
        self.assertEqual(c.get("/", headers=bad).status_code, 401)

    def test_no_password_means_open(self):
        c, _ = self.client()
        self.assertEqual(c.get("/").status_code, 200)

    # --- host / port from the platform
    def test_platform_port_makes_app_listen_on_all_interfaces(self):
        with mock.patch.dict(os.environ, {"PORT": "10000"}, clear=False):
            os.environ.pop("HOST", None)
            s = Settings.from_env()
        self.assertEqual((s.host, s.port), ("0.0.0.0", 10000))

    def test_local_default_stays_on_loopback(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("HOST", None)
            os.environ.pop("PORT", None)
            s = Settings.from_env()
        self.assertEqual((s.host, s.port), ("127.0.0.1", 5000))

    def test_no_hardcoded_localhost_in_frontend(self):
        root = Path(__file__).resolve().parent.parent
        for f in ("static/js/app.js", "templates/index.html", "static/css/style.css"):
            text = (root / f).read_text(encoding="utf-8")
            self.assertNotIn("localhost", text, f)
            self.assertNotIn("127.0.0.1", text, f)


if __name__ == "__main__":
    unittest.main()
