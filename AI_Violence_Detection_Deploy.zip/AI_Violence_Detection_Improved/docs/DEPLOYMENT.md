# Putting the website on the internet (beginner guide)

> **Status:** the project is *prepared* for deployment and tested locally. It is **not live**. Nothing has been deployed,
> because that needs your own account. After you finish the steps below you will get a public `https://...` link.

## 1. Which hosting should I use? (checked 23 Oct 2026)

This app runs a PyTorch video model, so it needs more memory than most free tiers give. Facts below come from the providers' own pages.

| Option | Cost | Fits this app? | Catch |
|---|---|---|---|
| **Google Cloud Run** (recommended) | Free monthly quota: 2 M requests, 180,000 vCPU-seconds, 360,000 GiB-seconds ([pricing](https://cloud.google.com/run/pricing)); beyond that about $0.000024 per vCPU-second | Yes - up to 32 GiB RAM and 8 vCPU per instance, 60-minute request limit ([quotas](https://docs.cloud.google.com/run/quotas)) | You must add a **billing account / card**. **Uploads are limited to 32 MiB** per request, so this project sets a 30 MB limit. Sleeps to zero when idle, so the first visit after a quiet period is slow (model reload). |
| **Render - paid 2 GB instance** | $25 / month for 1 CPU + 2 GB ([pricing](https://render.com/pricing)) | Probably yes | Costs money every month. No upload-size problem. |
| **Render - Free** | $0 | **Very likely not** | Only 512 MB RAM; PyTorch plus the model will probably run out of memory (I could not measure it). Also sleeps after 15 min idle and takes about a minute to wake ([docs](https://render.com/docs/free)). |
| **Hugging Face Spaces** | Free CPU tier existed | **No (for a new free account)** | The Hub docs say Docker Spaces on CPU now require a paid PRO plan ([docs](https://huggingface.co/docs/hub/spaces-overview)); community posts say the same. |

**Recommendation:** Google Cloud Run. In normal light use the free quota should cover you, but I **could not measure** how long one
analysis takes (the real model never ran in my sandbox), so I cannot promise a number. As a rough guide only: if one video took
30 s on 2 vCPU, that is 60 vCPU-seconds, so about 3,000 videos a month would fit in the free quota. Set a budget alert (step 2) so you are never surprised.
Free-quota amounts on that page are quoted for `us-central1`; I could not confirm they are identical in other regions.

**Model size is not a problem:** the weights are only 12 MB. The real cost is PyTorch itself (roughly 1.5-2 GB container image, several hundred MB of RAM).

## 2. One-time account setup (Google Cloud)

1. Go to <https://console.cloud.google.com> and sign in with a Google account.
2. Top bar -> project picker -> **New project** -> name it `violence-detector` -> **Create**. Note the **Project ID** (shown under the name).
3. Menu -> **Billing** -> link or create a billing account (needs a card; Google may place a small temporary hold).
4. **Safety net:** Billing -> **Budgets & alerts** -> **Create budget** -> amount `$1` -> save. You get an email if spending starts.

## 3. Deploy (all in the browser - nothing to install on Windows)

1. In the Google Cloud console click the **Cloud Shell** icon (`>_`, top right). A terminal opens at the bottom.
2. In Cloud Shell click the **three dots (⋮) -> Upload**, choose `AI_Violence_Detection_Deploy.zip`.
3. Type these commands (replace `YOUR_PROJECT_ID`):

```bash
unzip AI_Violence_Detection_Deploy.zip
cd AI_Violence_Detection_Improved
gcloud config set project YOUR_PROJECT_ID
gcloud run deploy violence-detector --source . --region asia-south1 --allow-unauthenticated --memory 2Gi --cpu 2 --max-instances 1 --timeout 900
```

4. If it asks to **enable APIs** or **create an Artifact Registry repository**, answer `y`.
5. Wait. The first build installs PyTorch, downloads the 12 MB model, and **checks that it loads** (build fails with a clear message if not). Expect several minutes.
6. At the end you will see: `Service URL: https://violence-detector-xxxxxxxx-el.a.run.app` - **that is your public HTTPS website.**

Why these flags: `--allow-unauthenticated` makes it public; `--max-instances 1` keeps job progress in one place (the app stores it in memory);
`--memory 2Gi` is a starting guess; `--timeout 900` allows up to 15 minutes per request.

## 4. Test the public URL

1. Open the URL on your phone (use mobile data, not your Wi-Fi) and on your PC. The padlock shows HTTPS.
2. The top-right pill should turn green ("Model ready"). The first visit after idle may show "Model loading..." for a while - wait.
3. Upload a short MP4 (under 30 MB). You should see a progress bar, then a red or green result.
4. Quick technical check from Cloud Shell: `curl https://YOUR-URL/api/health` -> look for `"state":"ready"`.
5. Logs: Cloud console -> Cloud Run -> `violence-detector` -> **Logs**.

## 5. Optional settings

* **Password-protect the site** (stops strangers using your quota): re-run the deploy command adding
  `--set-env-vars BASIC_AUTH_USER=demo,BASIC_AUTH_PASSWORD=choose-a-strong-password`. Visitors then see a browser login box.
* Longer videos / bigger limits: `--set-env-vars MAX_VIDEO_SECONDS=600` (costs more per video). The 30 MB upload cap is a Cloud Run limit; do not raise `MAX_UPLOAD_MB` above 30 there.
* **Update the site later:** run the same `gcloud run deploy ...` command again from the new folder.
* **Take it down:** `gcloud run services delete violence-detector --region asia-south1`.

## 6. Alternative: Render (paid 2 GB)

1. Put the project folder in a GitHub repository (github.com -> New repository -> upload files; do not upload `.env`).
2. <https://render.com> -> sign up -> **New + -> Web Service** -> connect the repo.
3. **Language: Docker.** Instance type: the **$25 / 1 CPU / 2 GB** one (not Free).
4. Environment variable: `MAX_UPLOAD_MB` = `100` (Render has no 32 MB cap). **Create Web Service.**
5. Render shows an `https://....onrender.com` URL when the deploy finishes.

## 7. Troubleshooting

| Problem | What to do |
|---|---|
| Build fails at `python download_model.py` | The build machine could not reach huggingface.co. Re-run the deploy; if it repeats, read the printed message (HTTP code). |
| Build fails at `python check_setup.py` | The real model could not load. Copy the last 30 lines of the build log and send them to me - this is the one part I could not test. |
| Page says **Model unavailable** / 503 | Open the Logs. Common cause: out of memory -> redeploy with `--memory 4Gi`. |
| "Memory limit exceeded" in logs | Same: use `--memory 4Gi` (costs more per second). |
| Upload fails for big files | Cloud Run accepts at most 32 MiB per request. Trim or compress the video (e.g. HandBrake, 720p). |
| First visit is slow | Normal after idle: the container and model must start. Keep one instance warm with `--min-instances 1` (this **costs money continuously**). |
| 429 "server busy" | Several people uploaded at once; the app handles one video at a time and queues at most 3. Wait a minute. |
| 401 login box | You set `BASIC_AUTH_*`; enter that user/password. |
| `Permission denied` / billing error in `gcloud` | Billing is not linked to the project (step 2.3). |
| `Quota exceeded` / unexpected charges | Check Billing -> Reports; lower `--max-instances` or delete the service. |

## 8. Privacy and licence reminders for a public site

* Visitors upload their own videos. Files are deleted right after analysis, but state this on your site and do not accept sensitive footage.
* The model licence is ambiguous (MIT tag vs "research / non-commercial" README). Keep the site educational / research.
* Accuracy is **not verified** at 95 % (see `docs/ACCURACY_REPORT.md`). Do not present results as reliable evidence about people.
